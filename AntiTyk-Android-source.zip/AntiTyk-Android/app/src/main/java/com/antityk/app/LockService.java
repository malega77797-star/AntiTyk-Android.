package com.antityk.app;

import android.app.*;
import android.content.*;
import android.graphics.PixelFormat;
import android.os.*;
import android.view.*;

public class LockService extends Service {
    private WindowManager manager;
    private View shield;
    private Handler handler = new Handler(Looper.getMainLooper());
    private int taps = 0;
    private long lastTap = 0;
    private boolean armed = false;
    private Runnable hold;
    @Override public void onCreate() {
        super.onCreate();
        NotificationChannel channel = new NotificationChannel("lock","АнтиТык",NotificationManager.IMPORTANCE_LOW);
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        Intent stop = new Intent(this,LockService.class).setAction("STOP");
        PendingIntent stopAction = PendingIntent.getService(this,1,stop,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Notification notification = new Notification.Builder(this,"lock")
            .setSmallIcon(android.R.drawable.ic_lock_lock).setContentTitle("АнтиТык включён")
            .setContentText("Экстренно выключить блокировку")
            .addAction(new Notification.Action.Builder(null,"Выключить",stopAction).build()).build();
        if (Build.VERSION.SDK_INT >= 34) startForeground(100,notification,android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(100,notification);
        manager = (WindowManager)getSystemService(WINDOW_SERVICE);
        shield = new View(this);
        shield.setBackgroundColor(0x01000000);
        shield.setOnTouchListener((v,event)->{
            int action=event.getActionMasked();
            int width=v.getWidth(),height=v.getHeight();
            boolean topLeft=event.getX()<width*.22f && event.getY()<height*.18f;
            boolean bottomRight=event.getX()>width*.78f && event.getY()>height*.82f;
            if (action==MotionEvent.ACTION_DOWN) {
                if (hold!=null) handler.removeCallbacks(hold);
                if (armed && bottomRight) {
                    hold=()->{
                        armed=false; taps=0;
                        Intent i=new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("unlock",true);
                        startActivity(i);
                    };
                    handler.postDelayed(hold,3000);
                } else if(topLeft) {
                    long now=SystemClock.uptimeMillis();
                    taps=(now-lastTap<1500)?taps+1:1; lastTap=now;
                    if(taps>=3){armed=true; taps=0; handler.postDelayed(()->armed=false,10000);}
                } else {taps=0;}
            }
            if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_CANCEL) {
                if(hold!=null){handler.removeCallbacks(hold);hold=null;}
            }
            return true;
        });
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        manager.addView(shield,params);
    }
    @Override public int onStartCommand(Intent i,int flags,int id) {
        if(i!=null && "STOP".equals(i.getAction())){stopSelf();return START_NOT_STICKY;}
        return START_NOT_STICKY;
    }
    @Override public void onDestroy(){if(hold!=null)handler.removeCallbacks(hold);handler.removeCallbacksAndMessages(null);if(shield!=null)manager.removeView(shield);super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
}
