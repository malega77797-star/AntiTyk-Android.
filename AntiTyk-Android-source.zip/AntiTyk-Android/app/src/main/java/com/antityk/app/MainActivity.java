package com.antityk.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.text.InputType;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    private final String PIN_KEY = "pin";
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 60, 40, 30);
        TextView title = new TextView(this);
        title.setText("АнтиТык\n\nБлокировка случайных касаний поверх мультфильма.\n\nДля разблокировки: три касания в левом верхнем углу, затем удержание в правом нижнем углу 3 секунды и PIN.\n\nЭкстренный выход: уведомление «АнтиТык».");
        title.setTextSize(18);
        layout.addView(title);
        Button pin = new Button(this); pin.setText("Установить / изменить PIN"); layout.addView(pin);
        pin.setOnClickListener(v -> askPin(false));
        Button start = new Button(this); start.setText("Включить блокировку"); layout.addView(start);
        start.setOnClickListener(v -> {
            if (!getPreferences(0).contains(PIN_KEY)) { Toast.makeText(this,"Сначала установите PIN",Toast.LENGTH_LONG).show(); return; }
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivity(i); return;
            }
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 3);
                Toast.makeText(this,"Разрешите уведомления, затем нажмите включить снова",Toast.LENGTH_LONG).show(); return;
            }
            Intent i = new Intent(this,LockService.class); i.setAction("START"); startForegroundService(i);
            Toast.makeText(this,"Блокировка включена. Вернитесь к видео.",Toast.LENGTH_LONG).show();
            moveTaskToBack(true);
        });
        setContentView(layout);
        if (getIntent().getBooleanExtra("unlock",false)) askPin(true);
    }
    private void askPin(boolean unlock) {
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        input.setHint("4-8 цифр");
        new AlertDialog.Builder(this).setTitle(unlock?"Разблокировать":"Новый PIN")
            .setView(input).setNegativeButton("Отмена",(d,w)->{if(unlock)finish();})
            .setPositiveButton("OK",(d,w)->{
                String value = input.getText().toString();
                if (unlock) {
                    if (value.equals(getPreferences(0).getString(PIN_KEY,""))) {
                        stopService(new Intent(this,LockService.class)); finish();
                    } else { Toast.makeText(this,"Неверный PIN",Toast.LENGTH_SHORT).show(); finish(); }
                } else if (value.matches("[0-9]{4,8}")) {
                    getPreferences(0).edit().putString(PIN_KEY,value).apply();
                    Toast.makeText(this,"PIN сохранён",Toast.LENGTH_SHORT).show();
                } else Toast.makeText(this,"Нужно 4-8 цифр",Toast.LENGTH_LONG).show();
            }).show();
    }
}
